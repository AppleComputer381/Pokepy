from tkinter import *
from affichage_pokedex import *

fenetre = Tk()
fenetre.title("accueil")
fenetre.geometry('640x480')

def pok():

	pokedex()
	fenetre.destroy()


bouton = Button(fenetre, text="afficher Pokedex", command = pok).place(relx=0.5, rely=0.5, anchor=CENTER)

fenetre.mainloop()