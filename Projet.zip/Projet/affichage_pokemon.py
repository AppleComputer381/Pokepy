from tkinter import *
from tkinter import filedialog
from pokedex import *

def aff_pokemon(name,filename):
	pokemon = Tk()
	pokemon.title(name)
	pokemon.geometry('640x480')

	values = filename[name]
	for value in values.values():
		label = Label(pokemon, text= value)
		label.pack()
		
