from tkinter import *
from tkinter import filedialog
from pokedex import *
from affichage_pokemon import *
def pokedex():

    filename = filedialog.askopenfilename(initialdir = "/", 
        title = "Select a File", 
        filetypes = (("", 
            "*.csv"), ("all files", "*.*")))
    pokedex = Tk()
    pokedex.title("Pokedex")


    button = []
    pokemon = {}
    filename = open_csv(filename)
    filename = valide(filename)
    poke = StringVar()

    def pokem(image):
        print(image)
        aff_pokemon(image, filename)


    for key in filename.keys():
        try:
            file = f"ico/{key}.png"
            key2 = PhotoImage(master = pokedex, file = file)
            pokemon[key2] = key

            button.append(key2)

        except:
            continue
    l = 0
    c = 0

    for a in button:
        
        if c == 14:
                c = 0
                l += 1
        else:

                
            Button(pokedex, image = a, width = 90, padx = 0, command = lambda: pokem(pokemon[image]) ).grid(row=l, column=c, columnspan=1,padx=5,pady=5)

            c += 1


    pokedex.mainloop()

